package com.order.service;

import com.order.wrapper.TransactionRequest;
import com.order.wrapper.TrasactionResponse;

public interface OrderService {
//	public OrderDetails addOrders(OrderDetailsRequest orderRequest);
	
	public TrasactionResponse addOrder(TransactionRequest transactionRequest);
	

}
