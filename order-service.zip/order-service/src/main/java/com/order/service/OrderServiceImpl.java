package com.order.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.order.entity.OrderDetails;
import com.order.repository.OrderRepository;
import com.order.wrapper.PaymentDetails;
import com.order.wrapper.TransactionRequest;
import com.order.wrapper.TrasactionResponse;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public TrasactionResponse addOrder(TransactionRequest transactionRequest) {
		OrderDetails orderDetails = transactionRequest.getOrderDetails();
		PaymentDetails paymentDetails = transactionRequest.getPaymentDetails();
		orderRepository.save(orderDetails);
		paymentDetails.setOrderId(orderDetails.getOrderId());
		System.err.println("orderDetails : "+ orderDetails);
		// rest call
		PaymentDetails postForObject = restTemplate.postForObject("http://PAYMENT-SERVICE/payment/addPayment", paymentDetails, PaymentDetails.class);
		System.err.println("postForObject : "+ postForObject);
		return new TrasactionResponse(orderDetails, postForObject.getPaymentId());
	}

//	@Autowired
//	private RestTemplate restTemplate;

//	@Override
//	public OrderDetails addOrders(OrderDetailsRequest orderRequest) {
//		System.err.println("Service() starts Executing...");
//		OrderDetails orderDetails = OrderDetails.builder()
//		.name(orderRequest.getName())
//		.price(orderRequest.getPrice())
//		.quantity(orderRequest.getQuantity()).build();
//		return orderRepository.save(orderDetails);
//	}

}
