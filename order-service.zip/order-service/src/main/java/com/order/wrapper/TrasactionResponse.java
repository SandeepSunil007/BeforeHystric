package com.order.wrapper;

import com.order.entity.OrderDetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class TrasactionResponse {
	
	private OrderDetails details;
	private int paymentId;

}
