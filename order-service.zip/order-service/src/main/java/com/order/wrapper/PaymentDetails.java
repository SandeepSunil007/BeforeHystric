package com.order.wrapper;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class PaymentDetails {
	private int paymentId;
	private String paymentStatus;
	private String transactionId;
	private int orderId;

}
