package com.order.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.order.response.OrderResponse;
import com.order.service.OrderService;
import com.order.wrapper.TransactionRequest;

@RestController
@RequestMapping("/order")
public class OrderController {

	@Autowired
	private OrderService orderService;

//	@PostMapping("/addOrder")
//	public ResponseEntity<OrderResponse> addOrders(@RequestBody OrderDetailsRequest detailsRequest) {
//		System.err.println("Order Controller Starts Executing...");
//		return ResponseEntity
//				.ok(OrderResponse.builder().isError(false).message("Data added into database succesfully..")
//						.data(orderService.addOrders(detailsRequest)).build());
//
//	}
//	
	
	@PostMapping("/addOrder")
	public ResponseEntity<OrderResponse> addOrders(@RequestBody TransactionRequest detailsRequest) {
		System.err.println("Order Controller Starts Executing...");
		return ResponseEntity
				.ok(OrderResponse.builder().isError(false).message("Data added into database succesfully..")
						.data(orderService.addOrder(detailsRequest)).build());

	}

}
