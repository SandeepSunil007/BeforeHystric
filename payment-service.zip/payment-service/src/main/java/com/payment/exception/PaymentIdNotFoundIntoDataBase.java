package com.payment.exception;

public class PaymentIdNotFoundIntoDataBase extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PaymentIdNotFoundIntoDataBase(String message) {
		super(message);
	}

}
