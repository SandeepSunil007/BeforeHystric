package com.payment.service;

import com.payment.entity.PaymentDetails;
import com.payment.request.PaymentDetailsRequest;

public interface PaymentService {
	public PaymentDetails addPayment(PaymentDetailsRequest paymentRequest);
	public PaymentDetails getPaymentDetailBasedOnId(Integer paymentId);
}
