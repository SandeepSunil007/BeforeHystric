package com.payment.service;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payment.entity.PaymentDetails;
import com.payment.exception.PaymentIdNotFoundIntoDataBase;
import com.payment.repository.PaymentRepository;
import com.payment.request.PaymentDetailsRequest;

@Service
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	private PaymentRepository paymentRepository;

//	@Override
//	public PaymentDetails addPayment(PaymentDetailsRequest paymentRequest) {
//		PaymentDetails paymentDetails = PaymentDetails.builder().paymentStatus(paymentRequest.getPaymentStatus())
//				.orderId(paymentRequest.getOrderId()).build();
//		paymentDetails.setTransactionId(UUID.randomUUID().toString());
//		return paymentRepository.save(paymentDetails);
//	}
	
	@Override
	public PaymentDetails addPayment(PaymentDetailsRequest paymentRequest) {
		System.err.println("Payment Service method calling...");
	    PaymentDetails paymentDetails = PaymentDetails.builder()
	            .paymentStatus(paymentRequest.getPaymentStatus())
	            .orderId(paymentRequest.getOrderId())
	            .transactionId(UUID.randomUUID().toString())
	            .build();
	    PaymentDetails savedPayment = paymentRepository.save(paymentDetails);
	    System.err.println("savedPayment : "+ savedPayment);
	    return savedPayment;
	}

	@Override
	public PaymentDetails getPaymentDetailBasedOnId(Integer paymentId) {
		return paymentRepository.findById(paymentId).orElseThrow(() -> new PaymentIdNotFoundIntoDataBase(paymentId+" Id Not Presnt Into Database"));
	}


}
