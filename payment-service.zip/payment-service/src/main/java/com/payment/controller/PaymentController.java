package com.payment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.payment.request.PaymentDetailsRequest;
import com.payment.response.PaymentResponse;
import com.payment.service.PaymentService;

@RestController
@RequestMapping("/payment")
public class PaymentController {

	@Autowired
	private PaymentService paymentService;

	@PostMapping("/addPayment")
	public ResponseEntity<PaymentResponse> addPaymentDetails(@RequestBody PaymentDetailsRequest paymentDetailsRequest) {
		System.err.println("payment controller method calling...!");
		return ResponseEntity.ok(PaymentResponse.builder().isError(false).message("Payment Details added succesfully..")
				.data(paymentService.addPayment(paymentDetailsRequest)).build());
	}

	@GetMapping("/getById/{paymentId}")
	public ResponseEntity<PaymentResponse> getPaymentById(@PathVariable Integer paymentId) {
		return ResponseEntity.ok(PaymentResponse.builder().isError(false).message("We got the data From Database")
				.data(paymentService.getPaymentDetailBasedOnId(paymentId)).build());
	}

}
