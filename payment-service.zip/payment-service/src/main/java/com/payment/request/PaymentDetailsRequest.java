package com.payment.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class PaymentDetailsRequest {
	private int paymentId;
	private String paymentStatus;
	private String transactionId;
	private int orderId;

}
